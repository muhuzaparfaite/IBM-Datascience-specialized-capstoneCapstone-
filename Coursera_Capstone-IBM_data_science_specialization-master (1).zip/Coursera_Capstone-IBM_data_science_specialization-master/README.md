# Coursera_Capstone-IBM_data_science_specialization
Capstone Project for the IBM data science specialization in Coursera: Battle of the Neighbourhoods
